"""
DAG Airflow : orchestre le pipeline complet LUCA par région.

    ingestion_kafka (Open-Meteo -> Kafka)
        -> archivage_minio (Kafka -> MinIO, JSON brut)
            -> traitement_spark_ml (MinIO -> SparkML -> Parquet)
                -> indexation_elasticsearch (Parquet -> Elasticsearch)
"""
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.bash import BashOperator

default_args = {
    "owner": "luca_climat",
    "depends_on_past": False,
    "start_date": datetime(2026, 1, 1),
    "retries": 1,
    "retry_delay": timedelta(minutes=2),
}

dag = DAG(
    "pipeline_predictions_climatiques",
    default_args=default_args,
    description="Pipeline LUCA par région : Ingestion Kafka -> MinIO -> Spark ML -> Elasticsearch",
    schedule_interval="@daily",
    catchup=False,
)

# Chemins montés dans le conteneur Airflow
CHEMIN_SCRIPTS = "/opt/scripts"
CHEMIN_SPARK_APPS = "/opt/spark-apps"

task_ingestion = BashOperator(
    task_id="ingestion_donnees",
    bash_command=f"cd {CHEMIN_SCRIPTS} && python kafka_producer_ingestion.py",
    dag=dag,
)

task_archivage = BashOperator(
    task_id="archivage_minio",
    bash_command=f"cd {CHEMIN_SCRIPTS} && python kafka_consumer_to_minio.py",
    dag=dag,
)

# Configuration modifiée : Ajout de tous les chemins d'accès pour common_config dans le conteneur Spark
task_spark_ml = BashOperator(
    task_id='traitement_spark_machine_learning',
    bash_command='docker exec -i luca-spark-jupyter spark-submit --packages org.apache.hadoop:hadoop-aws:3.3.4 /opt/spark-apps/traitement_climat_region.py',
    dag=dag,
)

task_index_es = BashOperator(
    task_id="indexation_elasticsearch",
    bash_command=f"cd {CHEMIN_SCRIPTS} && python indexer_elasticsearch.py",
    dag=dag,
)

task_ingestion >> task_archivage >> task_spark_ml >> task_index_es