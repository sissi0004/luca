"""
Étape 3 du pipeline : TRAITEMENT & MACHINE LEARNING (PySpark / SparkML).

Lit l'ensemble des fichiers JSON bruts (un par mesure région/pays) depuis le
bucket MinIO `weather-raw`, construit un historique par région, calcule les
fenêtres temporelles J-1 / J-2, entraîne un modèle de régression linéaire
(SparkML) pour prédire la température du lendemain, puis écrit le résultat
au format Parquet (Snappy) dans le bucket `weather-processed`.
"""
import sys
import os
import sys
sys.path.insert(0, '/opt/scripts')
sys.path.insert(0, '/opt/spark-apps')

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "scripts"))
from common_config import (  # noqa: E402
    MINIO_ENDPOINT,
    MINIO_ACCESS_KEY,
    MINIO_SECRET_KEY,
    MINIO_BUCKET_RAW,
    MINIO_BUCKET_PROCESSED,
)

from pyspark.sql import SparkSession, Window
from pyspark.sql import functions as F
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.regression import LinearRegression


def creer_session_spark():
    return (
        SparkSession.builder.appName("LUCA-Traitement-Climat-Region")
        # Injection directe des packages Hadoop/S3 pour éviter de dépendre de spark-submit
        .config("spark.jars.packages", "org.apache.hadoop:hadoop-aws:3.3.4,com.amazonaws:aws-java-sdk-bundle:1.12.262")
        # Configuration de la mémoire adaptée aux petites machines (8Go RAM)
        .config("spark.driver.memory", "512m")
        .config("spark.executor.memory", "512m")
        .config("spark.hadoop.fs.s3a.endpoint", MINIO_ENDPOINT)
        .config("spark.hadoop.fs.s3a.access.key", MINIO_ACCESS_KEY)
        .config("spark.hadoop.fs.s3a.secret.key", MINIO_SECRET_KEY)
        .config("spark.hadoop.fs.s3a.path.style.access", "true")
        .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false")
        .getOrCreate()
    )


def charger_donnees_brutes(spark):
    chemin = f"s3a://{MINIO_BUCKET_RAW}/brut_*.json"
    df = spark.read.json(chemin)
    colonnes_attendues = ["pays", "region", "iso3", "latitude", "longitude",
                           "date_climat", "temperature", "humidite", "precipitations"]
    for c in colonnes_attendues:
        if c not in df.columns:
            df = df.withColumn(c, F.lit(None))
    return df.select(*colonnes_attendues)


def construire_features_j1_j2(df):
    """Ajoute les colonnes temperature J-1 et J-2 par région, triées chronologiquement."""
    fenetre = Window.partitionBy("pays", "region").orderBy("date_climat")
    df = df.withColumn("temp_j1", F.lag("temperature", 1).over(fenetre))
    df = df.withColumn("temp_j2", F.lag("temperature", 2).over(fenetre))
    return df


def entrainer_et_predire(df):
    """Entraîne une régression linéaire (temp_j1, temp_j2, humidite -> temperature)
    et calcule une prédiction J+1 pour chaque ligne disposant d'un historique suffisant."""
    df_entrainement = df.filter(
        F.col("temp_j1").isNotNull() & F.col("temp_j2").isNotNull() & F.col("temperature").isNotNull()
    )

    if df_entrainement.count() < 5:
        # Historique insuffisant (premier run) : on utilise une heuristique simple
        # (persistance légèrement lissée) en attendant d'accumuler assez de données.
        df_resultat = df.withColumn(
            "temperature_predite",
            F.coalesce(F.col("temp_j1"), F.col("temperature")) * F.lit(1.0),
        )
        return df_resultat

    assembleur = VectorAssembler(
        inputCols=["temp_j1", "temp_j2", "humidite"],
        outputCol="features",
        handleInvalid="skip",
    )
    df_features = assembleur.transform(df_entrainement)

    regression = LinearRegression(featuresCol="features", labelCol="temperature")
    modele = regression.fit(df_features)

    print(f"📊 Modèle entraîné - R² = {modele.summary.r2:.4f}, RMSE = {modele.summary.rootMeanSquaredError:.4f}")

    df_a_predire = assembleur.transform(df.filter(F.col("temp_j1").isNotNull()))
    df_predictions = modele.transform(df_a_predire).withColumnRenamed("prediction", "temperature_predite")

    return df_predictions.drop("features")


def executer():
    spark = creer_session_spark()
    spark.sparkContext.setLogLevel("WARN")

    df_brut = charger_donnees_brutes(spark)
    df_features = construire_features_j1_j2(df_brut)
    df_resultat = entrainer_et_predire(df_features)

    colonnes_finales = ["pays", "region", "iso3", "latitude", "longitude",
                         "date_climat", "temperature", "temperature_predite",
                         "humidite", "precipitations"]
    df_final = df_resultat.select(*[c for c in colonnes_finales if c in df_resultat.columns])

    chemin_sortie = f"s3a://{MINIO_BUCKET_PROCESSED}/predictions_climat_region"
    df_final.coalesce(1).write.mode("overwrite").parquet(chemin_sortie)

    print(f"✅ Prédictions par région écrites dans {chemin_sortie}")
    spark.stop()


if __name__ == "__main__":
    executer()